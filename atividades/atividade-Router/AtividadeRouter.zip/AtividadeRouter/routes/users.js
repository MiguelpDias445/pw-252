const express = require('express');
const router = express.Router();

router.get('/:userid', (req, res) => {
  const id = req.params.userid;
  res.send(`<h1>Bem-vindo, usuário ${id}!</h1>`);
});

router.get('/', (req, res) => {
  res.redirect('/signup');
});

module.exports = router;
