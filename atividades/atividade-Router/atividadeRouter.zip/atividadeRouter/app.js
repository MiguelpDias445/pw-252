const express = require('express');
const path = require('path');
const app = express();
const port = 3000;

app.use((req, res, next) => {
  console.log(`Acesso: ${req.method} ${req.url}`);
  next();
});

const indexRouter = require('./routes/index');
const aboutRouter = require('./routes/about');
const dataRouter = require('./routes/data');
const usersRouter = require('./routes/users');

app.use('/', indexRouter);
app.use('/about', aboutRouter);
app.use('/data', dataRouter);
app.use('/users', usersRouter);


app.use((req, res) => {
  res.status(404).send('<h1>Página não existe(Erro 404)</h1><a href="/">PAGINA INICIAL</a>');
});

app.listen(port, () => {
  console.log(`Servidor em http://localhost:${port}`);
});
